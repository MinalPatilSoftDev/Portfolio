# Huddle-landing-page-with-tailwindCSS
Frontend Mentor challenge completed using HTML, JS, &amp; tailwindcss
